/*!
 *  @header EMGroupSharedFile.h
 *  @abstract Group share file
 *  @author Hyphenate
 *  @version 3.00
 */
#import <Foundation/Foundation.h>

@interface EMGroupSharedFile : NSObject

/*!
 *  Unique identifier of File
 */
@property (nonatomic, copy, readonly) NSString *fileId;

/*!
 *  Name of File
 */
@property (nonatomic, copy, readonly) NSString *fileName;

/*!
 *  Owner of File
 */
@property (nonatomic, copy, readonly) NSString *fileOwner;

/*!
 *  Create Time of File
 */
@property (nonatomic) long long createTime;

/*!
 *  Size of File
 */
@property (nonatomic) long long fileSize;

/*!
 *  Get Share file instance
 *
 *  @param aFileId  file id
 *
 *  @result Share file instance
 */
+ (instancetype)sharedFileWithId:(NSString*)aFileId;

@end
