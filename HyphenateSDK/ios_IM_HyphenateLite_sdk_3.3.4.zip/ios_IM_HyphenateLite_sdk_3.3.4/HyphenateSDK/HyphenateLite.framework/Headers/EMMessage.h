/*!
 *  @header EMMessage.h
 *  @abstract Chat message
 *  @author Hyphenate
 *  @version 3.00
 */

#import <Foundation/Foundation.h>

#import "EMMessageBody.h"

/*!
 *  Chat type
 */
typedef enum {
    EMChatTypeChat   = 0,   /*!  one to one chat type */
    EMChatTypeGroupChat,    /*!  Group chat type */
    EMChatTypeChatRoom,     /*!  Chatroom chat type */
} EMChatType;

/*!
 *   Message delivery status
 */
typedef enum {
    EMMessageStatusPending  = 0,    /*!  Pending */
    EMMessageStatusDelivering,      /*!  Delivering */
    EMMessageStatusSucceed,       /*!  Succeed */
    EMMessageStatusFailed,          /*!  Failed */
} EMMessageStatus;

/*!
 *  Message direction
 */
typedef enum {
    EMMessageDirectionSend = 0,    /*!  Send */
    EMMessageDirectionReceive,     /*!  Receive */
} EMMessageDirection;

/*!
 *  Chat message
 */
@interface EMMessage : NSObject

/*!
 *  Unique identifier of the message
 */
@property (nonatomic, copy) NSString *messageId;

/*!
 *  Unique identifier of conversation, the message's container object
 */
@property (nonatomic, copy) NSString *conversationId;

/*!
 *  Message delivery direction
 */
@property (nonatomic) EMMessageDirection direction;

/*!
 *  Message sender
 */
@property (nonatomic, copy) NSString *from;

/*!
 *  Message receiver
 */
@property (nonatomic, copy) NSString *to;

/*!
 *  Timestamp, the time of server received the message
 */
@property (nonatomic) long long timestamp;

/*!
 *  The time of client sends/receives the message
 */
@property (nonatomic) long long localTime;

/*!
 *  Chat type
 */
@property (nonatomic) EMChatType chatType;

/*!
 *  Message delivery status
 */
@property (nonatomic) EMMessageStatus status;

/*!
 *  Acknowledge if the message is read by the receipient. It indicates whether the sender has received a message read acknowledgement; or whether the recipient has sent a message read acknowledgement
 */
@property (nonatomic) BOOL isReadAcked;

/*!
 *  Acknowledge if the message is delivered. It indicates whether the sender has received a message deliver acknowledgement; or whether the recipient has sent a message deliver acknowledgement. SDK will automatically send delivery acknowledgement if EMOptions is set to enableDeliveryAck
 */
@property (nonatomic) BOOL isDeliverAcked;

/*!
 *  Whether the message has been read
 */
@property (nonatomic) BOOL isRead;

/*!
 *  Message body
 */
@property (nonatomic, strong) EMMessageBody *body;

/*!
 *  Message extension
 *
 *  Key type must be NSString. Value type must be NSString, or NSNumber object (including int, unsigned in, long long, double, use NSNumber (@YES/@NO) instead of BOOL).
 */
@property (nonatomic, copy) NSDictionary *ext;

/*!
 *  Initialize a message instance
 *
 *  @param aConversationId  Conversation id
 *  @param aFrom            Sender
 *  @param aTo              Receiver
 *  @param aBody            Message body
 *  @param aExt             Message extention
 *
 *  @result Message instance
 */
- (id)initWithConversationID:(NSString *)aConversationId
                        from:(NSString *)aFrom
                          to:(NSString *)aTo
                        body:(EMMessageBody *)aBody
                         ext:(NSDictionary *)aExt;


@end
