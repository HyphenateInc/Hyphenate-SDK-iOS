/*!
 *  @header EMCmdMessageBody.h
 *  @abstract Command message body
 *  @author Hyphenate
 *  @version 3.00
 */

#import <Foundation/Foundation.h>

#import "EMMessageBody.h"

/*!
 *  Command message body
 */
@interface EMCmdMessageBody : EMMessageBody

/*!
 *  Command content
 */
@property (nonatomic, copy) NSString *action;

/*!
 *  Command parameters, only compatible with old sdk versions. For SDK version 3.0+, use EMMessage's ext property instead
 */
@property (nonatomic, copy) NSArray *params;

/*!
 *  Construct command message body
 *  Developer self-defined command string that can be used for specifing custom action/command.
 *  ex. Share a location: mark the action with "location" string, then the parser knows that it's a command message about location sharing and find more attributes stored in extension property .ext.
 *  ex. Self-destructive message like Snapchat: mark the action ”selfDestructive“ and add the messageId of the message to be destruct and expiration time as part of .ext
 *
 *  @param aAction  Self-defined command string content
 *
 *  @result Instance of command message body
 */
- (instancetype)initWithAction:(NSString *)aAction;

@end
