/*!
 *  @header EMImageMessageBody.h
 *  @abstract Image message body
 *  @author Hyphenate
 *  @version 3.00
 */

#import <Foundation/Foundation.h>

#import "EMFileMessageBody.h"

/*!
 *  Image message body
 *  -(instancetype)initWithData:displayName:
 *  or
 *  -(instancetype)initWithData:thumbnailData:
 *  Note: SDK will compress the image based on the attribute compressRatio when delivering the image
 */
@interface EMImageMessageBody : EMFileMessageBody

/*!
 *  Resolution of the image
 */
@property (nonatomic) CGSize size;

/*!
 *  SDK will compress the image based on the attribute compressRatio when delivering the image
 *  Image compression ratio. 1.0x is original image without compression , default value is 0.6x (60% compression). SDK uses the default value if the given value is less than zero.
 */
@property (nonatomic) CGFloat compressionRatio;

/*!
 *  Display name of thumbnail
 */
@property (nonatomic, copy) NSString *thumbnailDisplayName;

/*!
 *  Local path of thumbnail
 *  UIImage *image = [UIImage imageWithContentsOfFile:thumbnailLocalPath];
 */
@property (nonatomic, copy) NSString *thumbnailLocalPath;

/*!
 *  Server url path of thumbnail
 */
@property (nonatomic, copy) NSString *thumbnailRemotePath;

/*!
 *  Secret key for downloading thumbnail image
 */
@property (nonatomic, copy) NSString *thumbnailSecretKey;

/*!
 *  Resolution of the thumbnail
 */
@property (nonatomic) CGSize thumbnailSize;

/*!
 *  File length of a thumbnail, in bytes
 */
@property (nonatomic) long long thumbnailFileLength;

/*!
 *  Download status of a thumbnail
 */
@property (nonatomic)EMDownloadStatus thumbnailDownloadStatus;

/*!
 *  Initialize an image message body instance
 *
 *  Image receiver will receive object thumbnail that generated based on sender's aData object.
 *  Adjust thumbnail resolution on Hyphenate conosle -> "Thumbnail Size" -> width and height. Unit in px.
 *  ex. aData resolution 200 x 400 (1：2), thumbnail resolution setting (width x height) 200 x 200, then will generate thumbnail in 100 x 200
 *  ex. aData resolution 600 x 300 (2：1), thumbnail resolution setting (width x height) 200 x 200, then will generate thumbnail in 200 x 100
 *
 *  Image sender can obtain thumbnail from thumbnailLocalPath
 *  Image receiver will get thumbnail stored under thumbnailRemotePath after a successful download automatically.
 *  However, if the automatic downloading failed, use the following method,
 *  downloadMessageThumbnail:progress:completion:
 *
 *  @param aData            original image object in NSData format
 *  @param aThumbnailData   Thumbnail in NSData format. Will not push to server, but only for local usage
 *
 *  @result An image message body instance
 */
- (instancetype)initWithData:(NSData *)aData
               thumbnailData:(NSData *)aThumbnailData;

#pragma mark - EM_DEPRECATED_IOS < 3.2.3

/*!
 *  Image compression ratio. 1.0 without compression, default value is 0.6. SDK uses the default value if the given value is less than zero.
 */
@property (nonatomic) CGFloat compressRatio __deprecated_msg("Use - compressionRatio");

@end
