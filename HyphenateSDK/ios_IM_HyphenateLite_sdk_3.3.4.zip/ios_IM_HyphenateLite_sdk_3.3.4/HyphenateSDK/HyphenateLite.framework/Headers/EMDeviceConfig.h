/*!
 *  @header EMDeviceConfig.h
 *  @abstract The info of logged in device
 *  @author Hyphenate
 *  @version 3.00
 */

#import <Foundation/Foundation.h>

@interface EMDeviceConfig : NSObject

/*!
 *  Device resources
 */
@property (nonatomic, readonly) NSString *resource;

/*!
 *  Device UUID
 */
@property (nonatomic, readonly) NSString *deviceUUID;

/*!
 *  Device name
 */
@property (nonatomic, readonly) NSString *deviceName;

@end
