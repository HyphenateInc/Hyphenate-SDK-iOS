/*!
 *  @header EMClient.h
 *  @abstract SDK Client
 *  @author Hyphenate
 *  @version 3.00
 */

#import <Foundation/Foundation.h>

#import "EMClientDelegate.h"
#import "EMMultiDevicesDelegate.h"
#import "EMOptions.h"
#import "EMPushOptions.h"
#import "EMError.h"

#import "IEMChatManager.h"
#import "IEMContactManager.h"
#import "IEMGroupManager.h"
#import "IEMChatroomManager.h"

#import "EMDeviceConfig.h"

/*!
 *  SDK Client
 */
@interface EMClient : NSObject
{
    EMPushOptions *_pushOptions;
}

/*!
 *  SDK version
 */
@property (nonatomic, strong, readonly) NSString *version;

/*!
 *  Current logged in user's username
 */
@property (nonatomic, strong, readonly) NSString *currentUsername;

/*!
 *  SDK setting options
 */
@property (nonatomic, strong, readonly) EMOptions *options;

/*!
 *  Apple Push Notification Service setting
 */
@property (nonatomic, strong, readonly) EMPushOptions *pushOptions;

/*!
 *  Chat Management
 */
@property (nonatomic, strong, readonly) id<IEMChatManager> chatManager;

/*!
 *  Contact Management
 */
@property (nonatomic, strong, readonly) id<IEMContactManager> contactManager;

/*!
 *  Group Management
 */
@property (nonatomic, strong, readonly) id<IEMGroupManager> groupManager;

/*!
 *  Chat Room Management
 */
@property (nonatomic, strong, readonly) id<IEMChatroomManager> roomManager;

/*!
 *  If SDK will automatically log into with previously logged in session. If the current login failed, then isAutoLogin attribute will be reset to NO, you need to set it back to YES in order to allow automatic login
 *  1. password changed
 *  2. deactivate, forced logout, etc
 */
@property (nonatomic, readonly) BOOL isAutoLogin;

/*!
 *  If a user logged in
 */
@property (nonatomic, readonly) BOOL isLoggedIn;

/*!
 *  Connection status to Hyphenate IM server
 */
@property (nonatomic, readonly) BOOL isConnected;

/*!
 *  Get SDK singleton instance
 */
+ (instancetype)sharedClient;


#pragma mark - Delegate

/*!
 *  Add delegate
 *
 *  @param aDelegate  Delegate
 *  @param aQueue     (optional) The queue of calling delegate methods. Pass in nil to run on main thread. 
 */
- (void)addDelegate:(id<EMClientDelegate>)aDelegate
      delegateQueue:(dispatch_queue_t)aQueue;

/*!
 *  Remove delegate
 *  
 *  @param aDelegate  Delegate
 */
- (void)removeDelegate:(id)aDelegate;

/*!
 *  Add multi-device delegate
 *
 *  @param aDelegate  Delegate
 *  @param aQueue     The queue of calling delegate methods
 */
- (void)addMultiDevicesDelegate:(id<EMMultiDevicesDelegate>)aDelegate
                  delegateQueue:(dispatch_queue_t)aQueue;

/*!
 *  Remove multi devices delegate
 *
 *  @param aDelegate  Delegate
 */
- (void)removeMultiDevicesDelegate:(id<EMMultiDevicesDelegate>)aDelegate;

#pragma mark - Initialize SDK

/*!
 *  Initialize the SDK
 *  
 *  @param aOptions SDK setting options
 *
 *  @result Error
 */
- (EMError *)initializeSDKWithOptions:(EMOptions *)aOptions;


#pragma mark - Change AppKey

/*!
 *  Change appkey. Can only change appkey when the user is logged out
 *
 *  @param aAppkey  appkey
 *
 *  @result Error
 */
- (EMError *)changeAppkey:(NSString *)aAppkey;


#pragma mark - User Registeration

/*!
 *  Register a new IM user
 *
 *  To ensure good reliability, registering new IM user via REST API from developer backend is highly recommended
 *
 *  @param aUsername  Username
 *  @param aPassword  Password
 *
 *  @result Error
 */
- (EMError *)registerWithUsername:(NSString *)aUsername
                         password:(NSString *)aPassword;

/*!
 *  Register a new IM user
 *
 *  To ensure good reliability, registering new IM user via REST API from developer backend is highly recommended
 *
 *  @param aUsername        Username
 *  @param aPassword        Password
 *  @param aCompletionBlock The callback of completion block
 *
 */
- (void)registerWithUsername:(NSString *)aUsername
                    password:(NSString *)aPassword
                  completion:(void (^)(NSString *aUsername, EMError *aError))aCompletionBlock;


#pragma mark - Login

/*!
 *  Login with password
 *
 *  Synchronization method will block the current thread
 *
 *  @param aUsername  Username
 *  @param aPassword  Password
 *
 *  @result Error
 */
- (EMError *)loginWithUsername:(NSString *)aUsername
                      password:(NSString *)aPassword;

/*!
 *  Login with password
 *
 *  @param aUsername        Username
 *  @param aPassword        Password
 *  @param aCompletionBlock The callback of completion block
 *
 */
- (void)loginWithUsername:(NSString *)aUsername
                 password:(NSString *)aPassword
               completion:(void (^)(NSString *aUsername, EMError *aError))aCompletionBlock;

/*!
 *  Login with token. Does not support automatic login
 *
 *  Synchronization method will block the current thread
 *
 *  @param aUsername  Username
 *  @param aToken     Token
 *
 *  @result Error
 */
- (EMError *)loginWithUsername:(NSString *)aUsername
                         token:(NSString *)aToken;

/*!
 *  Login with token. Does not support automatic login
 *
 *  @param aUsername        Username
 *  @param aToken           Token
 *  @param aCompletionBlock The callback of completion block
 *
 */
- (void)loginWithUsername:(NSString *)aUsername
                    token:(NSString *)aToken
               completion:(void (^)(NSString *aUsername, EMError *aError))aCompletionBlock;

#pragma mark - Logout

/*!
 *  Logout
 *
 *  Synchronization method will block the current thread
 *
 *  @param aIsUnbindDeviceToken Unbind device token to disable Apple Push Notification Service
 *
 *  @result Error
 */
- (EMError *)logout:(BOOL)aIsUnbindDeviceToken;

/*!
 *  Logout
 *
 *  @param aIsUnbindDeviceToken     Unbind device token to disable the Apple Push Notification Service
 *  @param aCompletionBlock         The callback of completion block
 *
 */
- (void)logout:(BOOL)aIsUnbindDeviceToken
    completion:(void (^)(EMError *aError))aCompletionBlock;

#pragma mark - APNs

/*!
 *  Device token binding is required to enable Apple Push Notification Service
 *
 *  Synchronization method will block the current thread
 *
 *  @param aDeviceToken  Device token to bind
 *
 *  @result Error
 */
- (EMError *)bindDeviceToken:(NSData *)aDeviceToken;

/*!
 *  Device token binding is required to enable Apple push notification service
 *
 *  @param aDeviceToken         Device token to bind
 *  @param aCompletionBlock     The callback block of completion
 */
- (void)registerForRemoteNotificationsWithDeviceToken:(NSData *)aDeviceToken
                                           completion:(void (^)(EMError *aError))aCompletionBlock;

/*!
 *  Set display name for Apple Push Notification message
 *
 *  Synchronization method will block the current thread
 *
 *  @param aNickname  Display name
 *
 *  @result Error
 */
- (EMError *)setApnsNickname:(NSString *)aNickname;

/*!
 *  Set display name for the push notification
 *
 *  @param aDisplayName     Display name of push
 *  @param aCompletionBlock The callback block of completion
 *
 */
- (void)updatePushNotifiationDisplayName:(NSString *)aDisplayName
                              completion:(void (^)(NSString *aDisplayName, EMError *aError))aCompletionBlock;

/*!
 *  Get Apple Push Notification Service options from the server
 *
 *  Synchronization method will block the current thread
 *
 *  @param pError  Error
 *
 *  @result Apple Push Notification Service options
 */
- (EMPushOptions *)getPushOptionsFromServerWithError:(EMError **)pError;

/*!
 *  Get Apple Push Notification Service options from the server
 *
 *  @param aCompletionBlock The callback of completion block
 */
- (void)getPushNotificationOptionsFromServerWithCompletion:(void (^)(EMPushOptions *aOptions, EMError *aError))aCompletionBlock;

/*!
 *  Update Apple Push Notification Service options to the server
 *
 *  Synchronization method will block the current thread
 *
 *  @result Error
 */
- (EMError *)updatePushOptionsToServer;

/*!
 *  Update Apple Push Notification Service options to the server
 *
 *  @param aCompletionBlock The callback block of completion
 */
- (void)updatePushNotificationOptionsToServerWithCompletion:(void (^)(EMError *aError))aCompletionBlock;

#pragma mark - Log

/*!
 *  Upload debugging log to server
 *
 *  Synchronization method will block the current thread
 *
 *  @result Error
 */
- (EMError *)uploadLogToServer;

/*!
 *  Upload debugging log to server
 *
 *  @param aCompletionBlock     The callback of completion block
 */
- (void)uploadDebugLogToServerWithCompletion:(void (^)(EMError *aError))aCompletionBlock;

/*!
 *  Compress the log file into a .gz file and return the gz file path. Recommend delete the gz file if file is no longer used
 *
 *  Synchronization method will block the current thread
 *
 *  @param pError Error
 *
 *  @result File path
 */
- (NSString *)getLogFilesPath:(EMError **)pError;

/*!
 *  Compress the log file into a .gz file and return the gz file path. Recommend delete the gz file if file is no longer used
 *
 *  @param aCompletionBlock     The callback of completion block
 */
- (void)getLogFilesPathWithCompletion:(void (^)(NSString *aPath, EMError *aError))aCompletionBlock;

#pragma mark - Multi Devices

/*!
 *  Get all the device information <EMDeviceConfig> that logged in to the server
 *
 *  Synchronization method will block the current thread
 *
 *  @param aUsername        Username
 *  @param aPassword        Password
 *  @param pError           Error
 *
 *  @result Information of logged in device <EMDeviceConfig>
 */
- (NSArray *)getLoggedInDevicesFromServerWithUsername:(NSString *)aUsername
                                             password:(NSString *)aPassword
                                                error:(EMError **)pError;

/*!
 *  Get all the device information <EMDeviceConfig> that logged in to the server
 *
 *  @param aUsername        Username
 *  @param aPassword        Password
 *  @param aCompletionBlock The callback block of completion
 *
 *  @result aList           Information of logged in device <EMDeviceConfig>
 */
- (void)getLoggedInDevicesFromServerWithUsername:(NSString *)aUsername
                                        password:(NSString *)aPassword
                                      completion:(void (^)(NSArray *aList, EMError *aError))aCompletionBlock;

/*!
 *  Force logout the specified device
 *
 *  device information can be obtained from getLoggedInDevicesFromServerWithUsername:password:error:
 *
 *  Synchronization method will block the current thread
 *
 *  @param aDevice          device information <EMDeviceConfig>
 *  @param aUsername        Username
 *  @param aPassword        Password
 *
 *  @result Error
 */
- (EMError *)kickDevice:(EMDeviceConfig *)aDevice
               username:(NSString *)aUsername
               password:(NSString *)aPassword;

/*!
 *  Force logout the specified device
 *
 *  device information can be obtained from getLoggedInDevicesFromServerWithUsername:password:error:
 *
 *  @param aDevice          device information <EMDeviceConfig>
 *  @param aUsername        Username
 *  @param aPassword        Password
 *  @param aCompletionBlock The callback block of completion
 */
- (void)kickDevice:(EMDeviceConfig *)aDevice
          username:(NSString *)aUsername
          password:(NSString *)aPassword
        completion:(void (^)(EMError *aError))aCompletionBlock;

/*!
 *  Force logout all logged in device for the specified user
 *
 *  Synchronization method will block the current thread
 *
 *  @param aUsername        Username
 *  @param aPassword        Password
 *
 *  @result Error
 */
- (EMError *)kickAllDevicesWithUsername:(NSString *)aUsername
                               password:(NSString *)aPassword;

/*!
 *  Force all logged in device to logout.
 *
 *  @param aUsername        Username
 *  @param aPassword        Password
 *  @param aCompletionBlock The callback block of completion
 */
- (void)kickAllDevicesWithUsername:(NSString *)aUsername
                          password:(NSString *)aPassword
                        completion:(void (^)(EMError *aError))aCompletionBlock;

#pragma mark - iOS

/*!
 *  Migrate the IM database to the latest SDK version
 *
 *  Synchronization method will block the current thread
 *
 *  @result Return YES for success
 */
- (BOOL)migrateDatabaseToLatestSDK;

/*!
 *  Disconnect from server when app enters background
 *
 *  @param aApplication  UIApplication
 */
- (void)applicationDidEnterBackground:(id)aApplication;

/*!
 *  Reconnect to server when app enters foreground
 *
 *  @param aApplication  UIApplication
 */
- (void)applicationWillEnterForeground:(id)aApplication;

/*!
 *  Invoked when receiving APNs in foreground
 *
 *  @param application  UIApplication
 *  @param userInfo     Push content
 */
- (void)application:(id)application didReceiveRemoteNotification:(NSDictionary *)userInfo;

#pragma mark - EM_DEPRECATED_IOS 3.2.3

/*!
 *  Add delegate
 *
 *  @param aDelegate  Delegate
 */
- (void)addDelegate:(id<EMClientDelegate>)aDelegate EM_DEPRECATED_IOS(3_1_0, 3_2_2, "Use -[IEMCallManager addDelegate:delegateQueue:]");

#pragma mark - EM_DEPRECATED_IOS < 3.2.3

/*!
 *  Register a new user
 *
 *  To enhance the reliability, registering new IM user through REST API from backend is highly recommended
 *
 *  @param aUsername        Username
 *  @param aPassword        Password
 *  @param aSuccessBlock    The callback block of success
 *  @param aFailureBlock    The callback block of failure
 *
 */
- (void)asyncRegisterWithUsername:(NSString *)aUsername
                         password:(NSString *)aPassword
                          success:(void (^)())aSuccessBlock
                          failure:(void (^)(EMError *aError))aFailureBlock __deprecated_msg("Use -registerWithUsername:password:completion:");

/*!
 *  Login
 *
 *  @param aUsername        Username
 *  @param aPassword        Password
 *  @param aSuccessBlock    The callback block of success
 *  @param aFailureBlock    The callback block of failure
 *
 */
- (void)asyncLoginWithUsername:(NSString *)aUsername
                      password:(NSString *)aPassword
                       success:(void (^)())aSuccessBlock
                       failure:(void (^)(EMError *aError))aFailureBlock __deprecated_msg("Use -loginWithUsername:password:completion");

/*!
 *  Logout
 *
 *  @param aIsUnbindDeviceToken Unbind device token to disable the Apple Push Notification Service
 *
 *  @result Error
 */
- (void)asyncLogout:(BOOL)aIsUnbindDeviceToken
            success:(void (^)())aSuccessBlock
            failure:(void (^)(EMError *aError))aFailureBlock __deprecated_msg("Use -logout:completion:");

/*!
 *  Bind device token
 *
 *  @param aDeviceToken     Device token to bind
 *  @param aSuccessBlock    The callback block of success
 *  @param aFailureBlock    The callback block of failure
 */
- (void)asyncBindDeviceToken:(NSData *)aDeviceToken
                     success:(void (^)())aSuccessBlock
                     failure:(void (^)(EMError *aError))aFailureBlock __deprecated_msg("Use -registerForRemoteNotificationsWithDeviceToken:completion:");

/*!
 *  Set display name for push notification
 *
 *  @param aNickname        Push Notification display name
 *  @param aSuccessBlock    The callback block of success
 *  @param aFailureBlock    The callback block of failure
 *
 */
- (void)asyncSetApnsNickname:(NSString *)aNickname
                     success:(void (^)())aSuccessBlock
                     failure:(void (^)(EMError *aError))aFailureBlock __deprecated_msg("Use -updatePushNotifiationDisplayName:copletion");

/*!
 *  Get apns options from the server
 *
 *  @param aSuccessBlock    The callback block of success
 *  @param aFailureBlock    The callback block of failure
 */
- (void)asyncGetPushOptionsFromServer:(void (^)(EMPushOptions *aOptions))aSuccessBlock
                              failure:(void (^)(EMError *aError))aFailureBlock __deprecated_msg("Use -getPushOptionsFromServerWithCompletion:");

/*!
 *  Update APNS options to the server
 *
 *  @param aSuccessBlock    The callback block of success
 *  @param aFailureBlock    The callback block of failure
 *
 */
- (void)asyncUpdatePushOptionsToServer:(void (^)())aSuccessBlock
                               failure:(void (^)(EMError *aError))aFailureBlock __deprecated_msg("Use -updatePushNotificationOptionsToServerWithCompletion:");

/*!
 *  Upload log to server
 *
 *  @param aSuccessBlock    The callback block of success
 *  @param aFailureBlock    The callback block of failure
 */
- (void)asyncUploadLogToServer:(void (^)())aSuccessBlock
                       failure:(void (^)(EMError *aError))aFailureBlock __deprecated_msg("Use -uploadDebugLogToServerWithCompletion:");

/*!
 *  iOS-specific, data migration to SDK3.0
 *
 *  Synchronization method will block the current thread
 *
 *  It's needed to call this method when update to SDK3.0, developers need to wait this method complete before DB related operations
 *
 *  @result Whether migration successful
 */
- (BOOL)dataMigrationTo3 __deprecated_msg("Use -migrateDatabaseToLatestSDK");

@end
