/*!
 *  @header EMChatroom.h
 *  @abstract Chatroom
 *  @author Hyphenate
 *  @version 3.00
 */

#import <Foundation/Foundation.h>

#import "EMCommonDefs.h"

/*!
 *  Chat room permission type
 */
typedef enum{
    EMChatroomPermissionTypeNone   = -1,    /*!  Unknown */
    EMChatroomPermissionTypeMember = 0,     /*!  Normal member */
    EMChatroomPermissionTypeAdmin,          /*!  Group admin */
    EMChatroomPermissionTypeOwner,          /*!  Group owner  */
}EMChatroomPermissionType;


/*!
 *  Chat room object
 */
@interface EMChatroom : NSObject

/*!
 *  Chat room id
 */
@property (nonatomic, copy, readonly) NSString *chatroomId;

/*!
 *  Subject of chat room
 */
@property (nonatomic, copy, readonly) NSString *subject;

/*!
 *  Description of chat room
 */
@property (nonatomic, copy, readonly) NSString *description;

/*!
 *  Owner of the chat room. Only one owner per chat room. 
 */
@property (nonatomic, copy, readonly) NSString *owner;

/*!
 *  Admins of the chatroom
 *
 */
@property (nonatomic, copy, readonly) NSArray *adminList;

/*!
 *  List of members in the chat room
 */
@property (nonatomic, copy, readonly) NSArray *memberList;

/*!
 *  Chatroom‘s blacklist of blocked users
 *
 *  Need owner's authority to access, return nil if user is not the chatroom owner.
 */
@property (nonatomic, strong, readonly) NSArray *blacklist;

/*!
 *  List of muted members<NSString>
 *
 *  Need owner's authority to access, return nil if user is not the chatroom owner.
 */
@property (nonatomic, strong, readonly) NSArray *muteList;

/*!
 *  The chatroom membership type of the current login account
 */
@property (nonatomic, readonly) EMChatroomPermissionType permissionType;

/*!
 *  The capacity of the chat room
 */
@property (nonatomic, readonly) NSInteger maxOccupantsCount;

/*!
 *  The total number of members in the chat room
 */
@property (nonatomic, readonly) NSInteger occupantsCount;

/*!
 *  Construct a chatroom instance with chatroom id
 *
 *  @param aChatroomId   Chatroom id
 *
 *  @result Chatroom instance
 */
+ (instancetype)chatroomWithId:(NSString *)aChatroomId;

#pragma mark - EM_DEPRECATED_IOS 3.3.0

/*!
 *  List of members in the chat room
 */
@property (nonatomic, copy, readonly) NSArray *members EM_DEPRECATED_IOS(3_1_0, 3_3_0, "Use -memberList");

/*!
 *  The total number of members in the chat room
 */
@property (nonatomic, readonly) NSInteger membersCount EM_DEPRECATED_IOS(3_1_0, 3_3_0, "Use -occupantsCount");

/*!
 *  The capacity of the chat room
 */
@property (nonatomic, readonly) NSInteger maxMembersCount EM_DEPRECATED_IOS(3_1_0, 3_3_0, "Use -maxOccupantsCount");

#pragma mark - EM_DEPRECATED_IOS < 3.2.3

/*!
 *  List of members in the chat room
 */
@property (nonatomic, copy, readonly) NSArray *occupants __deprecated_msg("Use - members");

/*!
 *  Initialize chatroom instance
 *
 *  Please use [+chatroomWithId:]
 *
 *  @result nil
 */
- (instancetype)init __deprecated_msg("Use +chatroomWithId:");

@end
