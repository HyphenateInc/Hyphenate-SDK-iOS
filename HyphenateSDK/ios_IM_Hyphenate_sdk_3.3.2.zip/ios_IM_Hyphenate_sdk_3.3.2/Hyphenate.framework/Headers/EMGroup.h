/*!
 *  @header EMGroup.h
 *  @abstract Group
 *  @author Hyphenate
 *  @version 3.00
 */

#import <Foundation/Foundation.h>

#import "EMCommonDefs.h"
#import "EMGroupOptions.h"

/*!
 *  Group permission type
 */
typedef enum{
    EMGroupPermissionTypeNone   = -1,    /*!  Unknown */
    EMGroupPermissionTypeMember = 0,     /*!  Normal member */
    EMGroupPermissionTypeAdmin,          /*!  Group admin */
    EMGroupPermissionTypeOwner,          /*!  Group owner  */
}EMGroupPermissionType;

/*!
 *  Group
 */
@interface EMGroup : NSObject

/*!
 *  Group id
 */
@property (nonatomic, copy, readonly) NSString *groupId;

/*!
 *  Subject of the group
 */
@property (nonatomic, copy, readonly) NSString *subject;

/*!
 *  Description of the group
 */
@property (nonatomic, copy, readonly) NSString *description;

/*!
 *  Announcement of the group
 */
@property (nonatomic, copy, readonly) NSString *announcement;

/*!
 *  Setting options of group
 */
@property (nonatomic, strong, readonly) EMGroupOptions *setting;

/*!
 *  Owner of the group
 *
 *  Each group only has one owner
 */
@property (nonatomic, copy, readonly) NSString *owner;

/*!
 *  Admins of the group
 *
 */
@property (nonatomic, copy, readonly) NSArray *adminList;

/*!
 *  Member list of the group
 */
@property (nonatomic, copy, readonly) NSArray *memberList;

/*!
 *  Group‘s blacklist of blocked users
 *
 *  Need owner's authority to access, return nil if user is not the group owner.
 */
@property (nonatomic, strong, readonly) NSArray *blacklist;

/*!
 *  List of muted members
 *
 *  Need owner's authority to access, return nil if user is not the group owner.
 */
@property (nonatomic, strong, readonly) NSArray *muteList;

/*!
 *  List of share file
 */
@property (nonatomic, strong, readonly) NSArray *sharedFileList;

/*!
 *  Is Apple Push Notification Service enabled for group
 */
@property (nonatomic, readonly) BOOL isPushNotificationEnabled;

/*!
 *  Whether is a public group
 */
@property (nonatomic, readonly) BOOL isPublic;

/*!
 *  Whether block the current group‘s messages
 */
@property (nonatomic, readonly) BOOL isBlocked;

/*!
 *  The group membership type of the current login account
 */
@property (nonatomic, readonly) EMGroupPermissionType permissionType;

/*!
 *  All occupants of the group, includes the group owner and admins and all other group members
 */
@property (nonatomic, strong, readonly) NSArray *occupants;

/*!
 *  The total number of group occupants, include owner, admins, members
 */
@property (nonatomic, readonly) NSInteger occupantsCount;

/*!
 *  Get group instance, create a instance if it does not exist
 *
 *  @param aGroupId  Group id
 *
 *  @result Group instance
 */
+ (instancetype)groupWithId:(NSString *)aGroupId;

#pragma mark - EM_DEPRECATED_IOS 3.3.0

/*!
 *  Member list of the group
 */
@property (nonatomic, copy, readonly) NSArray *members EM_DEPRECATED_IOS(3_1_0, 3_3_0, "Use -memberList");

/*!
 *  Group‘s blacklist of blocked users
 *
 *  Need owner's authority to access, return nil if user is not the group owner.
 */
@property (nonatomic, strong, readonly) NSArray *blackList EM_DEPRECATED_IOS(3_1_0, 3_3_0, "Use -blacklist");

/*!
 *  The total number of group members, include owner, admins, members
 */
@property (nonatomic, readonly) NSInteger membersCount EM_DEPRECATED_IOS(3_1_0, 3_3_0, "Use -occupantsCount");

#pragma mark - EM_DEPRECATED_IOS < 3.2.3

/*!
 *  Initialize a group instance
 *
 *  Please use [+groupWithId:]
 *
 *  @result nil
 */
- (instancetype)init __deprecated_msg("Use +groupWithId:");


/*!
 *  Group‘s blacklist of blocked users
 *
 *  Need owner's authority to access, return nil if user is not the group owner.
 */
@property (nonatomic, strong, readonly) NSArray *bans __deprecated_msg("Use - blackList");

@end
