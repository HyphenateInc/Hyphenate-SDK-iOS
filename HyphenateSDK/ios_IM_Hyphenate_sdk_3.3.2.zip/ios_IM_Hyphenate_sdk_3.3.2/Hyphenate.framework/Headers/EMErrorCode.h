/*!
 *  @header EMErrorCode.h
 *  @abstract SDK defined error type
 *  @author Hyphenate
 *  @version 3.00
 */

typedef enum{

    EMErrorGeneral = 1,                      /*!  General error */
    EMErrorNetworkUnavailable,               /*!  Network is unavaliable */
    EMErrorDatabaseOperationFailed,          /*!  Database operation failed */
    
    EMErrorInvalidAppkey = 100,              /*!  App (API) key is invalid */
    EMErrorInvalidUsername,                  /*!  Username is invalid */
    EMErrorInvalidPassword,                  /*!  Password is invalid */
    EMErrorInvalidURL,                       /*!  URL is invalid */
    EMErrorInvalidToken,                     /*!  Token is invalid */
    
    EMErrorUserAlreadyLogin = 200,           /*!  User already logged in */
    EMErrorUserNotLogin,                     /*!  User not logged in */
    EMErrorUserAuthenticationFailed,         /*!  Password authentication failed */
    EMErrorUserAlreadyExist,                 /*!  User already existed */
    EMErrorUserNotFound,                     /*!  User not found */
    EMErrorUserIllegalArgument,              /*!  Invalid argument */
    EMErrorUserLoginOnAnotherDevice,         /*!  User has logged in from another device */
    EMErrorUserRemoved,                      /*!  User was removed from server */
    EMErrorUserRegisterFailed,               /*!  Registration failed */
    EMErrorUpdateApnsConfigsFailed,          /*!  Update Apple Push Notification configurations failed */
    EMErrorUserPermissionDenied,             /*!  User has no access for this operation. */
    EMErrorUserBindDeviceTokenFailed,       /*!  Bind device token failed. */
    EMErrorUserUnbindDeviceTokenFailed,     /*!  Unbind device token failed. */
    EMErrorUserBindAnotherDevice,           /*!  Bind another device and do not allow auto. */
    EMErrorUserloginTooManyDevices,         /*!  User login on too many devices. */
    EMErrorUserMuted,                       /*!  User mutes in groups or chatrooms. */
    
    EMErrorServerNotReachable = 300,         /*!  Server is not reachable */
    EMErrorServerTimeout,                    /*!  Server response timeout */
    EMErrorServerBusy,                       /*!  Server is busy */
    EMErrorServerUnknownError,               /*!  Unknown server error */
    EMErrorServerGetDNSConfigFailed,         /*!  Get DNS config failed */
    EMErrorServerServingForbidden,           /*!  Service is forbidden */
    
    EMErrorFileNotFound = 400,               /*!  Cannot find the file */
    EMErrorFileInvalid,                      /*!  File is invalid */
    EMErrorFileUploadFailed,                 /*!  Upload file failed */
    EMErrorFileDownloadFailed,               /*!  Download file failed */
    EMErrorFileDeleteFailed,                 /*!  Delete file failed */
    EMErrorFileTooLarge,                     /*!  File too large */
    
    EMErrorMessageInvalid = 500,             /*!  Message is invalid */
    EMErrorMessageIncludeIllegalContent,      /*!  Message contains invalid content */
    EMErrorMessageTrafficLimit,              /*!  Unit time to send messages over the upper limit */
    EMErrorMessageEncryption,                /*!  Encryption error */
    
    EMErrorGroupInvalidId = 600,             /*!  Group Id is invalid */
    EMErrorGroupAlreadyJoined,               /*!  User already joined the group */
    EMErrorGroupNotJoined,                   /*!  User has not joined the group */
    EMErrorGroupPermissionDenied,            /*!  User does not have permission to access the operation */
    EMErrorGroupMembersFull,                 /*!  Group's max member reached */
    EMErrorGroupNotExist,                    /*!  Group does not exist */
    EMErrorGroupSharedFileInvalidId,         /*!  Share file Id is invalid */
    
    EMErrorChatroomInvalidId = 700,          /*!  Chatroom id is invalid */
    EMErrorChatroomAlreadyJoined,            /*!  User already joined the chatroom */
    EMErrorChatroomNotJoined,                /*!  User has not joined the chatroom */
    EMErrorChatroomPermissionDenied,         /*!  User does not have permission to access the operation */
    EMErrorChatroomMembersFull,              /*!  Chatroom's max member reached */
    EMErrorChatroomNotExist,                 /*!  Chatroom does not exist */
    
    EMErrorCallInvalidId = 800,              /*!  Call id is invalid */
    EMErrorCallBusy,                         /*!  User is busy */
    EMErrorCallRemoteOffline,                /*!  Callee is offline */
    EMErrorCallConnectFailed,                /*!  Establish connection failure */

}EMErrorCode;
