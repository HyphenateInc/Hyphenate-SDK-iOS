/*!
 *  @header IEMChatroomManager.h
 *  @abstract This protocol defines the chat room operations
 *  @author Hyphenate
 *  @version 3.00
 */

#import <Foundation/Foundation.h>

#import "EMCommonDefs.h"
#import "EMChatroomManagerDelegate.h"
#import "EMChatroomOptions.h"
#import "EMChatroom.h"
#import "EMPageResult.h"

#import "EMCursorResult.h"

@class EMError;

/*!
 *  Chatroom operations
 */
@protocol IEMChatroomManager <NSObject>

@required

#pragma mark - Delegate

/*!
 *  Add delegate
 *
 *  @param aDelegate  Delegate
 *  @param aQueue     The queue of call delegate method
 */
- (void)addDelegate:(id<EMChatroomManagerDelegate>)aDelegate
      delegateQueue:(dispatch_queue_t)aQueue;

/*!
 *  Remove delegate
 *
 *  @param aDelegate  Delegate
 */
- (void)removeDelegate:(id<EMChatroomManagerDelegate>)aDelegate;

#pragma mark - Fetch Chatrooms

/*!
 *  Get pagesize number chatroom from server.
 *
 *  Synchronization method will block the current thread
 *
 *  @param aPageNum         Page number
 *  @param aPageSize        Page size
 *  @param pError   Error
 *
 *  @return Chat room list<EMChatroom>
 */
- (EMPageResult *)getChatroomsFromServerWithPage:(NSInteger)aPageNum
                                        pageSize:(NSInteger)aPageSize
                                           error:(EMError **)pError;

/*!
 *  Get all the chatrooms from server
 *
 *  @param aPageNum         Page number
 *  @param aPageSize        Page size
 *  @param aCompletionBlock     The callback block of completion
 *
 */

- (void)getChatroomsFromServerWithPage:(NSInteger)aPageNum
                              pageSize:(NSInteger)aPageSize
                            completion:(void (^)(EMPageResult *aResult, EMError *aError))aCompletionBlock;

#pragma mark - Create

/*!
 *  Create a chatroom
 *
 *  Synchronization method will block the current thread
 *
 *  @param aSubject             Subject
 *  @param aDescription         Description
 *  @param aInvitees            Members, without creater
 *  @param aMessage             Invitation message
 *  @param aMaxMembersCount     Max members count
 *  @param pError               Error
 *
 *  @return    Created chatroom
 */
- (EMChatroom *)createChatroomWithSubject:(NSString *)aSubject
                           description:(NSString *)aDescription
                              invitees:(NSArray *)aInvitees
                               message:(NSString *)aMessage
                          maxMembersCount:(NSInteger)aMaxMembersCount
                                 error:(EMError **)pError;

/*!
 *  Create a group
 *
 *  @param aSubject                 Group subject
 *  @param aDescription             Group description
 *  @param aInvitees                Group members, without creater
 *  @param aMessage                 Invitation message
 *  @param aMaxMembersCount         Max members count
 *  @param aCompletionBlock         The callback block of completion
 *
 */
- (void)createChatroomWithSubject:(NSString *)aSubject
                      description:(NSString *)aDescription
                         invitees:(NSArray *)aInvitees
                          message:(NSString *)aMessage
                  maxMembersCount:(NSInteger)aMaxMembersCount
                       completion:(void (^)(EMChatroom *aChatroom, EMError *aError))aCompletionBlock;

#pragma mark - Edit Chatroom

/*!
 *  Join a chatroom
 *
 *  Synchronization method will block the current thread
 *
 *  @param aChatroomId  Chatroom id
 *  @param pError       Error
 *
 *  @result Joined chatroom
 */
- (EMChatroom *)joinChatroom:(NSString *)aChatroomId
                       error:(EMError **)pError;

/*!
 *  Join a chatroom
 *
 *  @param aChatroomId      Chatroom id
 *  @param aCompletionBlock     The callback block of completion
 *
 */
- (void)joinChatroom:(NSString *)aChatroomId
          completion:(void (^)(EMChatroom *aChatroom, EMError *aError))aCompletionBlock;

/*!
 *  Leave a chatroom
 *
 *  Synchronization method will block the current thread
 *
 *  @param aChatroomId  Chatroom id
 *  @param pError       Error
 *
 */
- (void)leaveChatroom:(NSString *)aChatroomId
                error:(EMError **)pError;

/*!
 *  Leave a chatroom
 *
 *  @param aChatroomId      Chatroom id
 *  @param aCompletionBlock     The callback block of completion
 *
 */
- (void)leaveChatroom:(NSString *)aChatroomId
           completion:(void (^)(EMError *aError))aCompletionBlock;

/*!
 *  Destroy a group, owner‘s authority is required
 *
 *  Synchronization method will block the current thread
 *
 *  @param aChatroomId  Chatroom id
 *
 *  @result    Error, return nil if success
 */
- (EMError *)destroyChatroom:(NSString *)aChatroomId;

/*!
 *  Destroy a group, owner‘s authority is required
 *
 *  @param aChatroomId      Chatroom id
 *  @param aCompletionBlock The callback block of completion
 *
 */
- (void)destroyChatroom:(NSString *)aChatroomId
             completion:(void (^)(EMError *aError))aCompletionBlock;

#pragma mark - Fetch

/*!
 *  Fetch chatroom's specification
 *
 *  Synchronization method, will block the current thread
 *
 *  @param aChatroomId           Chatroom id
 *  @param pError                Error
 *
 *  @return    Chatroom instance
 */
- (EMChatroom *)getChatroomSpecificationFromServerWithId:(NSString *)aChatroomId
                                                   error:(EMError **)pError;

/*!
 *  Fetch chat room specifications
 *
 *  @param aChatroomId           Chatroom id
 *  @param aCompletionBlock      The callback block of completion
 *
 */
- (void)getChatroomSpecificationFromServerWithId:(NSString *)aChatroomId
                                      completion:(void (^)(EMChatroom *aChatroom, EMError *aError))aCompletionBlock;

/*!
 *  Get the list of chatroom members from the server
 *
 *  @param aChatroomId      Chatroom id
 *  @param aCursor          Cursor, input nil the first time
 *  @param aPageSize        Page size
 *  @param pError           Error
 *
 *  @return    List and cursor
 *
 */
- (EMCursorResult *)getChatroomMemberListFromServerWithId:(NSString *)aChatroomId
                                                   cursor:(NSString *)aCursor
                                                 pageSize:(NSInteger)aPageSize
                                                    error:(EMError **)pError;

/*!
 *  Get the list of chatroom members from the server
 *
 *  @param aChatroomId      Chatroom id
 *  @param aCursor          Cursor, input nil the first time
 *  @param aPageSize        Page size
 *  @param aCompletionBlock The callback block of completion
 *
 */
- (void)getChatroomMemberListFromServerWithId:(NSString *)aChatroomId
                                       cursor:(NSString *)aCursor
                                     pageSize:(NSInteger)aPageSize
                                   completion:(void (^)(EMCursorResult *aResult, EMError *aError))aCompletionBlock;

/*!
 *  Get the blacklist of chatroom from the server, need owner / admin permissions
 *
 *  @param aChatroomId      Chatroom id
 *  @param aPageNum         Page number
 *  @param aPageSize        Page size
 *  @param pError           Error
 *
 */
- (NSArray *)getChatroomBlacklistFromServerWithId:(NSString *)aChatroomId
                                       pageNumber:(NSInteger)aPageNum
                                         pageSize:(NSInteger)aPageSize
                                            error:(EMError **)pError;

/*!
 *  Get chatroom's blacklist, need owner / admin permissions
 *
 *  @param aChatroomId      Chatroom id
 *  @param aPageNum         Page number
 *  @param aPageSize        Page size
 *  @param aCompletionBlock The callback block of completion
 *
 */
- (void)getChatroomBlacklistFromServerWithId:(NSString *)aChatroomId
                                  pageNumber:(NSInteger)aPageNum
                                    pageSize:(NSInteger)aPageSize
                                  completion:(void (^)(NSArray *aList, EMError *aError))aCompletionBlock;

/*!
 *  Get the mutes of chatroom from the server
 *
 *  @param aChatroomId      Chatroom id
 *  @param aPageNum         Page number
 *  @param aPageSize        Page size
 *  @param pError           Error
 *
 */
- (NSArray *)getChatroomMuteListFromServerWithId:(NSString *)aChatroomId
                                      pageNumber:(NSInteger)aPageNum
                                        pageSize:(NSInteger)aPageSize
                                           error:(EMError **)pError;

/*!
 *  Get the mutes of chatroom from the server
 *
 *  @param aChatroomId      Chatroom id
 *  @param aPageNum         Page number
 *  @param aPageSize        Page size
 *  @param aCompletionBlock The callback block of completion
 *
 */
- (void)getChatroomMuteListFromServerWithId:(NSString *)aChatroomId
                                 pageNumber:(NSInteger)aPageNum
                                   pageSize:(NSInteger)aPageSize
                                 completion:(void (^)(NSArray *aList, EMError *aError))aCompletionBlock;

/*!
 *  Get the announcement of chatroom from the server
 *
 *  @param aChatroomId      Chatroom id
 *  @param pError           error
 *
 *  @return    The announcement of chatroom
 */
- (NSString *)getChatroomAnnouncementWithId:(NSString *)aChatroomId
                                      error:(EMError **)pError;

/*!
 *  Get the announcement of chatroom from the server
 *
 *  @param aChatroomId      Chatroom id
 *  @param aCompletionBlock The callback block of completion
 *
 */
- (void)getChatroomAnnouncementWithId:(NSString *)aChatroomId
                           completion:(void (^)(NSString *aAnnouncement, EMError *aError))aCompletionBlock;

#pragma mark - Edit

/*!
 *  Change chatroom subject, owner‘s authority is required
 *
 *  Synchronization method will block the current thread
 *
 *  @param aSubject     New subject
 *  @param aChatroomId  Chatroom id
 *  @param pError       Error
 *
 *  @result    Chatroom instance
 */
- (EMChatroom *)updateSubject:(NSString *)aSubject
                  forChatroom:(NSString *)aChatroomId
                        error:(EMError **)pError;

/*!
 *  Change the chatroom subject, owner‘s authority is required
 *
 *  @param aSubject         New subject
 *  @param aChatroomId      Chatroom id
 *  @param aCompletionBlock The callback block of completion
 *
 */
- (void)updateSubject:(NSString *)aSubject
          forChatroom:(NSString *)aChatroomId
           completion:(void (^)(EMChatroom *aChatroom, EMError *aError))aCompletionBlock;

/*!
 *  Change chatroom description, owner‘s authority is required
 *
 *  Synchronization method will block the current thread
 *
 *  @param aDescription New description
 *  @param aChatroomId  Chatroom id
 *  @param pError       Error
 *
 *  @result    Chatroom
 */
- (EMChatroom *)updateDescription:(NSString *)aDescription
                      forChatroom:(NSString *)aChatroomId
                            error:(EMError **)pError;

/*!
 *  Change the chatroom description, owner‘s authority is required
 *
 *  @param aDescription     New description
 *  @param aChatroomId      Chatroom id
 *  @param aCompletionBlock The callback block of completion
 *
 */
- (void)updateDescription:(NSString *)aDescription
              forChatroom:(NSString *)aChatroomId
               completion:(void (^)(EMChatroom *aChatroom, EMError *aError))aCompletionBlock;

/*!
 *  Remove members from a chatroom, required owner‘s authority
 *
 *  Synchronization method will block the current thread
 *
 *  @param aMembers     Users to be removed
 *  @param aChatroomId  Chatroom id
 *  @param pError       Error
 *
 *  @result    Chatroom instance
 */
- (EMChatroom *)removeMembers:(NSArray *)aMembers
                 fromChatroom:(NSString *)aChatroomId
                        error:(EMError **)pError;

/*!
 *  Remove members from a group, owner‘s authority is required
 *
 *  @param aMembers         Users to be removed
 *  @param aChatroomId      Chatroom id
 *  @param aCompletionBlock The callback block of completion
 *
 */
- (void)removeMembers:(NSArray *)aMembers
         fromChatroom:(NSString *)aChatroomId
           completion:(void (^)(EMChatroom *aChatroom, EMError *aError))aCompletionBlock;

/*!
 *  Add users to chatroom blacklist, required owner‘s authority
 *
 *  Synchronization method will block the current thread
 *
 *  @param aMembers     Users to be added
 *  @param aChatroomId  Chatroom id
 *  @param pError       Error
 *
 *  @result    Chatroom instance
 */
- (EMChatroom *)blockMembers:(NSArray *)aMembers
                fromChatroom:(NSString *)aChatroomId
                       error:(EMError **)pError;

/*!
 *  Add users to chatroom blacklist, owner‘s authority is required
 *
 *  @param aMembers         Users to be added
 *  @param aChatroomId      Chatroom id
 *  @param aCompletionBlock The callback block of completion
 *
 */
- (void)blockMembers:(NSArray *)aMembers
        fromChatroom:(NSString *)aChatroomId
          completion:(void (^)(EMChatroom *aChatroom, EMError *aError))aCompletionBlock;


/*!
 *  Remove users from chatroom blacklist, required owner‘s authority
 *
 *  Synchronization method will block the current thread
 *
 *  @param aMembers     Users to be removed
 *  @param aChatroomId  Chatroom id
 *  @param pError       Error
 *
 *  @result    Chatroom instance
 */
- (EMChatroom *)unblockMembers:(NSArray *)aMembers
                  fromChatroom:(NSString *)aChatroomId
                         error:(EMError **)pError;

/*!
 *  Remove users from chatroom blacklist, owner‘s authority is required
 *
 *  @param aMembers         Users to be removed
 *  @param aChatroomId      Chatroom id
 *  @param aCompletionBlock The callback block of completion
 *
 */
- (void)unblockMembers:(NSArray *)aMembers
          fromChatroom:(NSString *)aChatroomId
            completion:(void (^)(EMChatroom *aChatroom, EMError *aError))aCompletionBlock;

/*!
 *  Change chatroom owner, need Owner permissions
 *
 *  Synchronization method will block the current thread
 *
 *  @param aChatroomId  Chatroom id
 *  @param aNewOwner    New owner
 *  @param pError       Error
 *
 *  @result    Chatroom instance
 */
- (EMChatroom *)updateChatroomOwner:(NSString *)aChatroomId
                           newOwner:(NSString *)aNewOwner
                              error:(EMError **)pError;

/*!
 *  Change chatroom owner, need Owner permissions
 *
 *  @param aChatroomId      Chatroom id
 *  @param aNewOwner        New owner
 *  @param aCompletionBlock The callback block of completion
 *
 */
- (void)updateChatroomOwner:(NSString *)aChatroomId
                   newOwner:(NSString *)aNewOwner
                 completion:(void (^)(EMChatroom *aChatroom, EMError *aError))aCompletionBlock;

/*!
 *  Add chatroom admin, need Owner permissions
 *
 *  Synchronization method will block the current thread
 *
 *  @param aAdmin       Admin
 *  @param aChatroomId  Chatroom id
 *  @param pError       Error
 *
 *  @result    Group instance
 */
- (EMChatroom *)addAdmin:(NSString *)aAdmin
              toChatroom:(NSString *)aChatroomId
                   error:(EMError **)pError;

/*!
 *  Add chatroom admin, need Owner permissions
 *
 *  @param aAdmin           Admin
 *  @param aChatroomId      Chatroom id
 *  @param aCompletionBlock The callback block of completion
 *
 */
- (void)addAdmin:(NSString *)aAdmin
      toChatroom:(NSString *)aChatroomId
      completion:(void (^)(EMChatroom *aChatroomp, EMError *aError))aCompletionBlock;

/*!
 *  Remove chatroom admin, need Owner permissions
 *
 *  Synchronization method will block the current thread
 *
 *  @param aAdmin       Admin
 *  @param aChatroomId  Chatroom id
 *  @param pError       Error
 *
 *  @result    Chatroom instance
 */
- (EMChatroom *)removeAdmin:(NSString *)aAdmin
               fromChatroom:(NSString *)aChatroomId
                      error:(EMError **)pError;

/*!
 *  Remove chatroom admin, need Owner permissions
 *
 *  @param aAdmin           Admin
 *  @param aChatroomId      Chatroom id
 *  @param aCompletionBlock The callback block of completion
 *
 */
- (void)removeAdmin:(NSString *)aAdmin
       fromChatroom:(NSString *)aChatroomId
         completion:(void (^)(EMChatroom *aChatroom, EMError *aError))aCompletionBlock;


/*!
 *  Mute chatroom members, need Owner / Admin permissions
 *
 *  Synchronization method will block the current thread
 *
 *  @param aMuteMembers         The list of mute, type is <NSString>
 *  @param aMuteMilliseconds    Muted time duration in millisecond
 *  @param aChatroomId          Chatroom id
 *  @param pError               Error
 *
 *  @result    Chatroom instance
 */
- (EMChatroom *)muteMembers:(NSArray *)aMuteMembers
           muteMilliseconds:(NSInteger)aMuteMilliseconds
               fromChatroom:(NSString *)aChatroomId
                      error:(EMError **)pError;

/*!
 *  Mute chatroom members, need Owner / Admin permissions
 *
 *  Synchronization method will block the current thread
 *
 *  @param aMuteMembers         The list of mute, type is <NSString>
 *  @param aMuteMilliseconds    Muted time duration in millisecond
 *  @param aChatroomId          Chatroom id
 *  @param aCompletionBlock     The callback block of completion
 *
 */
- (void)muteMembers:(NSArray *)aMuteMembers
   muteMilliseconds:(NSInteger)aMuteMilliseconds
       fromChatroom:(NSString *)aChatroomId
         completion:(void (^)(EMChatroom *aChatroom, EMError *aError))aCompletionBlock;

/*!
 *  Unmute chatroom members, need Owner / Admin permissions
 *
 *  Synchronization method will block the current thread
 *
 *  @param aMembers         The list of unmute, type is <NSString>
 *  @param aChatroomId      Chatroom id
 *  @param pError           Error
 *
 *  @result    Chatroom instance
 */
- (EMChatroom *)unmuteMembers:(NSArray *)aMembers
                 fromChatroom:(NSString *)aChatroomId
                        error:(EMError **)pError;

/*!
 *  Unmute chatroom members, need Owner / Admin permissions
 *
 *  Synchronization method will block the current thread
 *
 *  @param aMembers         The list of unmute, type is <NSString>
 *  @param aChatroomId      Chatroom id
 *  @param aCompletionBlock The callback block of completion
 *
 */
- (void)unmuteMembers:(NSArray *)aMembers
         fromChatroom:(NSString *)aChatroomId
           completion:(void (^)(EMChatroom *aChatroom, EMError *aError))aCompletionBlock;

/*!
 *  Change the announcement of chatroom, need Owner / Admin permissions
 *
 *  Synchronization method will block the current thread
 *
 *  @param aChatroomId      Chatroom id
 *  @param aAnnouncement    announcement of chatroom
 *  @param pError           error
 *
 *  @result    Chatroom instance
 */
- (EMChatroom *)updateChatroomAnnouncementWithId:(NSString *)aChatroomId
                                    announcement:(NSString *)aAnnouncement
                                           error:(EMError **)pError;

/*!
 *  Change the announcement of chatroom, need Owner / Admin permissions
 *
 *  @param aChatroomId      Chatroom id
 *  @param aAnnouncement    announcement of chatroom
 *  @param aCompletionBlock The callback block of completion
 *
 */
- (void)updateChatroomAnnouncementWithId:(NSString *)aChatroomId
                            announcement:(NSString *)aAnnouncement
                              completion:(void (^)(EMChatroom *aChatroom, EMError *aError))aCompletionBlock;

#pragma mark - EM_DEPRECATED_IOS 3.3.0

/*!
 *  Fetch chatroom's specification
 *
 *  Synchronization method, will block the current thread
 *
 *  @param aChatroomId           Chatroom id
 *  @param aIncludeMembersList   Whether to get member list，When YES, returns 200 members
 *  @param pError                Error
 *
 *  @return    Chatroom instance
 */
- (EMChatroom *)fetchChatroomInfo:(NSString *)aChatroomId
               includeMembersList:(BOOL)aIncludeMembersList
                            error:(EMError **)pError EM_DEPRECATED_IOS(3_1_0, 3_3_0, "Use -[IEMChatroomManager getChatroomSpecificationFromServerWithId:error:]");

/*!
 *  Fetch chat room specifications
 *
 *  @param aChatroomId           Chatroom id
 *  @param aIncludeMembersList   Whether to get member list，When YES, returns 200 members
 *  @param aCompletionBlock      The callback block of completion
 *
 */
- (void)getChatroomSpecificationFromServerByID:(NSString *)aChatroomId
                            includeMembersList:(BOOL)aIncludeMembersList
                                    completion:(void (^)(EMChatroom *aChatroom, EMError *aError))aCompletionBlock EM_DEPRECATED_IOS(3_1_0, 3_3_0, "Use -[IEMChatroomManager getChatroomSpecificationFromServerWithId:completion:]");

#pragma mark - EM_DEPRECATED_IOS 3.2.3

/*!
 *  Add delegate
 *
 *  @param aDelegate  Delegate
 */
- (void)addDelegate:(id<EMChatroomManagerDelegate>)aDelegate EM_DEPRECATED_IOS(3_1_0, 3_2_2, "Use -[IEMChatroomManager addDelegate:delegateQueue:]");

#pragma mark - EM_DEPRECATED_IOS < 3.2.3

/*!
 *  Get all the chatrooms from server
 *
 *  Synchronization method will block the current thread
 *
 *  @param pError   Error
 *
 *  @return Chat room list<EMChatroom>
 */
- (NSArray *)getAllChatroomsFromServerWithError:(EMError **)pError __deprecated_msg("Use -getChatroomsFromServerWithPage");

/*!
 *  Get all the chatrooms from server
 *
 *  @param aCompletionBlock     The callback block of completion
 *
 */
- (void)getAllChatroomsFromServerWithCompletion:(void (^)(NSArray *aList, EMError *aError))aCompletionBlock __deprecated_msg("Use -getChatroomsFromServerWithPage");

/*!
 *  Get all the chatrooms from server
 *
 *  @param aSuccessBlock         The callback block of success
 *  @param aFailureBlock         The callback block of failure
 *
 */
- (void)asyncGetAllChatroomsFromServer:(void (^)(NSArray *aList))aSuccessBlock
                               failure:(void (^)(EMError *aError))aFailureBlock __deprecated_msg("Use -getAllChatroomsFromServerWithCompletion:");

/*!
 *  Join a chatroom
 *
 *  @param aChatroomId      Chatroom id
 *  @param aSuccessBlock    The callback block of success
 *  @param aFailureBlock    The callback block of failure
 *
 */
- (void)asyncJoinChatroom:(NSString *)aChatroomId
                  success:(void (^)(EMChatroom *aRoom))aSuccessBlock
                  failure:(void (^)(EMError *aError))aFailureBlock __deprecated_msg("Use -joinChatroom:completion:");

/*!
 *  Leave a chatroom
 *
 *  @param aChatroomId      Chatroom id
 *  @param aSuccessBlock    The callback block of success
 *  @param aFailureBlock    The callback block of failure
 *
 *  @result Leaved chatroom
 */
- (void)asyncLeaveChatroom:(NSString *)aChatroomId
                   success:(void (^)(EMChatroom *aRoom))aSuccessBlock
                   failure:(void (^)(EMError *aError))aFailureBlock __deprecated_msg("Use -leaveChatroom:completion:");

/*!
 *  Fetch chatroom's specification
 *
 *  @param aChatroomId           Chatroom id
 *  @param aIncludeMembersList   Whether get member list
 *  @param aSuccessBlock         The callback block of success
 *  @param aFailureBlock         The callback block of failure
 *
 */
- (void)asyncFetchChatroomInfo:(NSString *)aChatroomId
            includeMembersList:(BOOL)aIncludeMembersList
                       success:(void (^)(EMChatroom *aChatroom))aSuccessBlock
                       failure:(void (^)(EMError *aError))aFailureBlock __deprecated_msg("Use -getChatroomSpecificationFromServerByID:includeMembersList:completion:");
@end
