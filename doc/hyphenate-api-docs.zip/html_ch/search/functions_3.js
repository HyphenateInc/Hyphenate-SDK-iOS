var searchData=
[
  ['changedescription_3aforgroup_3aerror_3a',['changeDescription:forGroup:error:',['../protocol_i_e_m_group_manager-p.html#abf9fda9a1df498d36716301814417280',1,'IEMGroupManager-p']]],
  ['changegroupsubject_3aforgroup_3aerror_3a',['changeGroupSubject:forGroup:error:',['../protocol_i_e_m_group_manager-p.html#a090b2759d586d91044f439ee111e2b3d',1,'IEMGroupManager-p']]],
  ['chatroomwithid_3a',['chatroomWithId:',['../interface_e_m_chatroom.html#a47814fcec0824c7417ed3f69202f4aec',1,'EMChatroom']]],
  ['clearframe',['clearFrame',['../interface_open_g_l_view20.html#a737bf7ddf15bf9841fa49c96c1bd64f4',1,'OpenGLView20']]],
  ['creategroupwithsubject_3adescription_3ainvitees_3amessage_3asetting_3aerror_3a',['createGroupWithSubject:description:invitees:message:setting:error:',['../protocol_i_e_m_group_manager-p.html#ae54181cbadb18880c8264c743d3a05cd',1,'IEMGroupManager-p']]],
  ['cursorresultwithlist_3aandcursor_3a',['cursorResultWithList:andCursor:',['../interface_e_m_cursor_result.html#ad277e648781862b9b45ff595929b2465',1,'EMCursorResult']]]
];
