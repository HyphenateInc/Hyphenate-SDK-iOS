var searchData=
[
  ['fetchgroupbanslist_3aerror_3a',['fetchGroupBansList:error:',['../protocol_i_e_m_group_manager-p.html#a14f2a9c6a9840fbaedb4357ecc0c367b',1,'IEMGroupManager-p']]],
  ['fetchgroupinfo_3aincludememberslist_3aerror_3a',['fetchGroupInfo:includeMembersList:error:',['../protocol_i_e_m_group_manager-p.html#a356e2a7e17e6d0b3d6aacf7d1996ab14',1,'IEMGroupManager-p']]]
];
