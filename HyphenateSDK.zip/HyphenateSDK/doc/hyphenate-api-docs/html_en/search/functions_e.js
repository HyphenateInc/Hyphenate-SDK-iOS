var searchData=
[
  ['updatemessage_3a',['updateMessage:',['../interface_e_m_conversation.html#a4dca17de552da315a566bb1596cd1ce1',1,'EMConversation::updateMessage:()'],['../protocol_i_e_m_chat_manager-p.html#a2ee224a596c75fa427d9e0f973f4520d',1,'IEMChatManager-p::updateMessage:()']]]
];
